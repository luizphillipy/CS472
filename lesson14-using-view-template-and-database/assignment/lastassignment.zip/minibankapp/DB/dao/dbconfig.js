/**
 * dbconfig.js
 */
 "use strict"

 //Setup the Database config info
 
 const dbConfig = {
     host:"localhost",
     user: "db-admin",
     password: "12345678",
     database:"accounts-db"
 }
 
 module.exports = dbConfig;